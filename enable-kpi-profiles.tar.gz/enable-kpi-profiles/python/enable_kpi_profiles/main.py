# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service
from .kpi import enableKpis


# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class ServiceCallbacks(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')
        enableKpis(service, self.log)

# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        self.register_service('enable-kpi-profiles-servicepoint', ServiceCallbacks)

        #initialization for decrypting password
        with ncs.maapi.Maapi() as m:
            m.install_crypto_keys()

    def teardown(self):
        self.log.info('Main FINISHED')
