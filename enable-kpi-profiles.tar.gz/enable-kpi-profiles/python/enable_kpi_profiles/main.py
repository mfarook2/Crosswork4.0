# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service
from .kpi import enableKpis
from ncs.dp import Action

# ---------------
# ACTIONS EXAMPLE
# ---------------
class EnableKPI(Action):
    @Action.action
    def cb_action(self, uinfo, name, kp, input, output, trans):
        self.log.info('action name: ', name)

        with ncs.maapi.single_read_trans('admin', 'enable-kpi') as t:
            root = ncs.maagic.get_root(t, shared=False)
            service_name = str(kp).split("{")[1].split("}")[0]
            if root.enable_kpi_profiles.exists(service_name):
                service = root.enable_kpi_profiles[service_name]
                result = enableKpis(service, self.log)
                self.log.info('action enableKPI():return code  ::', result)
            else:
                self.log.info('action enableKPI() no service with name: ' + service_name)

# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class ServiceCallbacks(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')

# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        self.register_service('enable-kpi-profiles-servicepoint', ServiceCallbacks)

        self.register_service('enable-kpi-profiles-action', EnableKPI)

        #initialization for decrypting password
        with ncs.maapi.Maapi() as m:
            m.install_crypto_keys()

    def teardown(self):
        self.log.info('Main FINISHED')
