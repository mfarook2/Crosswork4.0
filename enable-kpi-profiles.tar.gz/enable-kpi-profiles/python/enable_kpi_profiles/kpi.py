from xml.dom.minidom import parse
import xml.dom.minidom
import requests
import _ncs
import yaml


# dcloud setup
NSO_SERVICE_PATH = "/home/cisco/ncs-run/packages/"
CONFIG_FILE_PATH = "/home/cisco/ncs-run/packages/enable-kpi-profiles/python/enable_kpi_profiles/config.yaml"

Ticket_Token_Header = {
    'Content-Type': "application/x-www-form-urlencoded",
    'Accept': "text/plain",
    'Cache-Control': "no-cache",
}


def formatPayload(keylist, log):
    log.info('formatpayload() : formatpayload')
    log.info('TYPE keyList ::', type(keylist))
    value_list = ""
    for value in keylist:
        value_list += "\"" + value + "\"" + ","
    value_list = value_list.rstrip(",")
    return value_list


def build_object_list(log):
    with open(CONFIG_FILE_PATH) as f:
        data = yaml.load(f, Loader=yaml.FullLoader)
        log.info("YAML data Type:", data)
        xr_object_names = []
        for key, value in (data['KPI']['XR']).items():
            xr_object_names.append(key)
        log.info('XR KEYS  ', xr_object_names)
        xe_object_names = []
        for key, value in (data['KPI']['IOS_XE']).items():
            xe_object_names.append(key)
        log.info('XE KEYS  ', xe_object_names)
        return (data, xr_object_names, xe_object_names)


class KPIProfile:
    xr_object_list = []
    xe_object_list = []
    xr_kpis = []
    xe_kpis = []
    xr_devices = []
    xe_devices = []

    def __init__(self, file_name, log):
        self.file_name = file_name
        self.log = log

    def generate_kpi_list(self):
        doc = xml.dom.minidom.parse(NSO_SERVICE_PATH
                                    + self.file_name
                                    + '/templates/'
                                    + self.file_name
                                    + '-template.xml')
        node_list = doc.getElementsByTagName("config")
        self.log.info("DOC::", node_list)

        object_list = build_object_list(self.log)
        kpis_input_list = object_list[0]
        self.xr_object_list = object_list[1]
        self.xe_object_list = object_list[2]
        self.log.info("kpis_input_list", kpis_input_list)
        self.log.info("xr_object_list", self.xr_object_list)
        self.log.info("xe_object_list", self.xe_object_list)

        # for node in doc.documentElement.childNodes:
        self.xr_object_list.append('additional')
        for node in node_list:
            for obj in self.xr_object_list:
                if isinstance(node, xml.dom.minidom.Element):
                    if node.getElementsByTagName(obj):
                        self.xr_kpis.extend(kpis_input_list['KPI']['XR'][obj])
        self.xr_kpis.extend(kpis_input_list['KPI']['XR']['additional'])
        self.log.info("FINAL KPI List: ", self.xr_kpis)
        return self.xr_kpis


class Crosswork:
    def __init__(self, service, log):
        self.service = service
        self.log = log
        self.crosswork = service.crosswork
        self.log.info("NSO Service Name ::", self.service.serviceName)
        self.log.info("Crosswork IP address::", self.crosswork.ipaddress)
        self.log.info("Crosswork IP port::", self.crosswork.port)
        self.log.info("Crosswork IP username::", self.crosswork.username)
        self.log.info("Crosswork IP password::", self.crosswork.password)
        self.log.info("Decrypted Crosswork IP password::",
                      _ncs.decrypt(str(self.crosswork.password)))

    def get_ticket(self):
        self.log.info('getTicket() : Getting Ticket')
        url = "https://" \
              + self.crosswork.ipaddress \
              + ":" \
              + str(self.crosswork.port) \
              + "/crosswork/sso/v1/tickets/"
        querystring = {"username": self.crosswork.username,
                       "password": _ncs.decrypt(str(self.crosswork.password))}
        payload = ""
        response = requests.request("POST", url,
                                    data=payload,
                                    headers=Ticket_Token_Header,
                                    params=querystring,
                                    verify=False)
        self.log.info('getTicket() : return code  ::', response.text)
        return response.text

    def get_token(self):
        self.log.info('getToken() : Getting Token')
        url = "https://" \
              + self.crosswork.ipaddress \
              + ":" + str(self.crosswork.port) \
              + "/crosswork/sso/v1/tickets/" \
              + self.get_ticket()
        payload = "service=https%3A%2F%2F" \
                  + self.crosswork.ipaddress \
                  + "%3A30603%2Fapp-dashboard&undefined="
        response = requests.request("POST",
                                    url,
                                    data=payload,
                                    headers=Ticket_Token_Header,
                                    verify=False)
        self.log.info('getToken() : return code  ::', response.text)
        return response.text

    def create_kpi_profile(self, log):
        self.log.info('create_kpi_profiles')

        generate_kpi_profile = KPIProfile(self.service.serviceName, log)
        kpi_list = generate_kpi_profile.generate_kpi_list()
        self.log.info("KPI List: ", kpi_list)

        KPI_PROFILE_STRUCTURE = '{\"id\": \"\",' \
                                ' \"name\": \"KPI_PROFILE_NAME\",' \
                                ' \"description\": \"KPI_PROFILE_DESCRIPTION\",' \
                                ' \"kpis\": [ KPI_STRUCTURE ]}'
        kpi_structure = '{ \"kpi_id\": \"KPI_ID\", \"cadence\": 60, \"alerting\": true }'

        KPI_PROFILE_STRUCTURE = KPI_PROFILE_STRUCTURE.replace("KPI_PROFILE_NAME",
                                                              self.service.serviceName)
        KPI_PROFILE_STRUCTURE = KPI_PROFILE_STRUCTURE.replace("KPI_PROFILE_DESCRIPTION",
                                                              self.service.serviceName
                                                              + "Profile")

        kpi_input_list = ""
        for kpi in list(set(kpi_list)):
            kpi_input_list += kpi_structure
            kpi_input_list = kpi_input_list.replace("KPI_ID", kpi)
            kpi_input_list += ","
        kpi_input_list = kpi_input_list[:-1]
        KPI_PROFILE_STRUCTURE = \
            KPI_PROFILE_STRUCTURE.replace("KPI_STRUCTURE", kpi_input_list)
        self.log.info('KPI_PROFILE_STRUCTURE  ::', KPI_PROFILE_STRUCTURE)

        url = "https://" + self.crosswork.ipaddress + ":" + str(
            self.crosswork.port) + "/crosswork/hi/v1/kpiprofilemgmt/write"
        headers = {'Content-Type': "application/json",
                   'Authorization': "Bearer " + self.get_token(),
                   'Cache-control': "no-cache",
                   }
        response = ""
        response = (requests.request("POST",
                                     url,
                                     data=KPI_PROFILE_STRUCTURE,
                                     headers=headers,
                                     verify=False))
        self.log.info('create_kpi_profile: return code ::', response.text)

    def enable_kpi_profile(self):
        self.log.info('enableKpis() : enable Kpis')
        url = "https://" \
              + self.crosswork.ipaddress \
              + ":" \
              + str(self.crosswork.port) \
              + "/crosswork/hi/v1/kpiprofileassoc/write"
        headers = {'Content-Type': "application/json",
                   'Authorization': "Bearer " + self.get_token(),
                   'Cache-control': "no-cache",}
        self.log.info('TYPE service.device ::', type(self.service.device))
        device_list = formatPayload(self.service.device, self.log)
        kpi_profile_payload ='{"devices": [device_list], "kpi_profiles":["' + self.service.serviceName + '"]}'
        kpi_profile_payload = kpi_profile_payload.replace("device_list", device_list)
        self.log.info('kpi_profile_payload ::', kpi_profile_payload)

        response = ""
        response = (requests.request("POST",
                                     url,
                                     data=kpi_profile_payload,
                                     headers=headers,
                                     verify=False))
        self.log.info('enableKpis(): return code ::', response.text)

        return response


# ---------------------------------------------
# Auto enables kpis based on the NSO service
# ---------------------------------------------
def enableKpis(service, log):
    log.info('enableKpis() : enable Kpis')
    cw = Crosswork(service, log)
    cw.create_kpi_profile(log)
    result = cw.enable_kpi_profile()
    log.info('enableKpis() : return code ::', result.text)
